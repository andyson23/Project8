package week10;

import java.util.Iterator;

import week10.jsjf.LinkedBinarySearchTree;
import week10.jsjf.exceptions.ElementNotFoundException;

public class BSTExample {

	public static void main(String[] args) {
		LinkedBinarySearchTree<Integer> t = new LinkedBinarySearchTree<Integer>();
		LinkedBinarySearchTree<StudentRecord> s = new LinkedBinarySearchTree<StudentRecord>();
		
		for(int ii=0;ii<20;ii++) {
			t.addElement((int)(Math.random()*100));
		}
		
		s.addElement(new StudentRecord("Harrison Ford", 3.5));
		s.addElement(new StudentRecord("Mark Hamil", 3.1));
		s.addElement(new StudentRecord("Carrie Fisher", 3.1));
		s.addElement(new StudentRecord("Adam Driver", 3.8));
		s.addElement(new StudentRecord("Daisy Ridley", 3.3));
		s.addElement(new StudentRecord("John Boyega", 3.3));
		s.addElement(new StudentRecord("Oscar Isaac", 3.3));
		s.addElement(new StudentRecord("Lupita Nyong'o", 3.9));
		s.addElement(new StudentRecord("Andy Serkis", 3.3));
		s.addElement(new StudentRecord("Domhnall Gleeson", 3.4));
	
		System.out.println("Tree: " + t);
		System.out.println("Tree: " + s);

		System.out.println("Find 5: " + t.find(5));
		try {
			System.out.print("Find Mark Hamil: ");
			System.out.println(s.find(new StudentRecord("Mark Hamil", 0.0)));
		}
		catch (ElementNotFoundException e) {
			System.out.println("Unable to find record!" );
		}
		try {
			System.out.print("Find William Shatner: ");
			System.out.println(s.find(new StudentRecord("William Shatner", 0.0)));
		}
		catch (ElementNotFoundException e) {
			System.out.println("Unable to find record!" );
		}
		
		System.out.print("\nPre-Order: ");
		Iterator<Integer> preorder = t.iteratorPreOrder();
		while (preorder.hasNext()) {
			System.out.print(preorder.next() + " ");
		}
		
		System.out.print("\nIn-Order: ");
		Iterator<Integer> inorder = t.iteratorInOrder();
		while (inorder.hasNext()) {
			System.out.print(inorder.next() + " ");
		}		
		
		System.out.print("\nPost-Order: ");
		Iterator<Integer> postorder = t.iteratorPostOrder();
		while (postorder.hasNext()) {
			System.out.print(postorder.next() + " ");
		}

		System.out.print("\nIn-Order:\n");
		Iterator<StudentRecord> inorder2 = s.iteratorInOrder();
		while (inorder2.hasNext()) {
			System.out.print(inorder2.next() + "\n");
		}	
	}

}
